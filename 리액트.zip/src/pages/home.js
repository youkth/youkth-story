import React from 'react'
import Container from '../components/shared/container'

function HomePage(){
  return (
    <Container basic>메인입니다.</Container>
  )
}

export default HomePage