import React from 'react'
import Container from '../components/shared/container'

function ErrorPage(){
  return (
    <Container basic>에러입니다.</Container>
  )
}

export default ErrorPage