import React from 'react'
import Container from '../components/shared/container'
import Signin from '../components/signin'

function SigninPage(){
  return (
    <Container>
      <Signin />
    </Container>
  )
}

export default SigninPage