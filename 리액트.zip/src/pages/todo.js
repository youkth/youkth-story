import React from 'react'
import Container from '../components/shared/container'
import Todo from '../components/todo'

function TodoPage(){
  return (
    <Container>
      <Todo />
    </Container>
  )
}

export default TodoPage