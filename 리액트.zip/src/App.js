//import React from 'react';
//import styled from 'styled-components'
//import Signin from './components/signin'

//import logo from './logo.svg';
//import './App.css';

//***가상 회원정보 가져오기***//
/*const getFakeMembers = count => new Promise((resolves, rejects) => {
    const api = `https://api.randomuser.me/?nat=US&results=${count}`
    const request = new XMLHttpRequest()
    request.open('GET', api)
    request.onload = () =>
    (request.status === 200) ?
    resolves(JSON.parse(request.response).results):
    rejects(Error(request.statusText))
    request.onerror = (err) => rejects(err)
    request.send()

  })

getFakeMembers(10).then(
  members => console.log(members),
  err => console.error(
    new Error("?????????????")
  )
)*/

/*let colors = [
  {title:'빨강'},
  {title:'초록'},
  {title:'노랑'}
]*/

//const addColor = (title, array) => array.concat({title})

//const addColor = (title, array) => [{title}, ...array]

//console.log(addColor('연초록',colors))

//const sc=['z1111','w22222','w33333']

//const wsc =sc.filter(ssc => ssc !== 'z1111')

//arr.filter(callback(element[, index[, array]])[, thisArg])

//console.log(wsc)

/* const Arr = [
  {name:'첫번째'},
  {name:'두번째'},
  {name:'새번째'},
  {name:'내번째'}
] */

/*function Add({item}){
return(
  <div>
    {item.name}
  </div>
)
}{Arr.map((item,index) => <Add item={item} key={index} />)}*/

/*function Add({old,name,arr}){
  return(
    <ul>
    {
      arr.map((item, index) => <li key={index}>{item.name}</li>)
    }
    </ul>
  )
}*/


/* function App() {
  return (
    <div>
      내용 테스트
      <Add old={"첫번째"} name={"????????"} arr={Arr}/>
    </div>
  );
} */

/* import React from 'react';
//import styled from 'styled-components'
import GlobalStyle from './components/common/global-style'
import Container from './components/shared/container'
import Todo from './components/todo' */

/* for(let i=0; i<=tagArr.length-1; i++){
  let getTag=`${tagArr[i]}`
  //let getTag = Container.withComponent(`${getTag}`);
  console.log(getTag);
} */


/* const Section = Container.withComponent('section');
const Article = Container.withComponent('article');
const Ul = Container.withComponent('ul');
const Li = Container.withComponent('li'); */

/* function App(){
  //return <Signin />
  return(
    <div className="wrap">
      <GlobalStyle />
      <Container flex height="1000px" bgcolor="yellow">
        <section width="20%" height="500px" bgcolor="red">
            <article border="1px solid black">
              <img src="" alt=""/>
              <strong>테스트</strong>
              <p>내용 내용 내용</p>
              <div>
                <button>로그아웃</button>
                <button>프로필 수정</button>
              </div>
            </article>
            <ul>
              <li>내프로필</li>
              <li>근태현황</li>
              <li>야근신청</li>
              <li>휴가신청</li>
            </ul>
        </section>
        
        <section width="40%" height="500px" bgcolor="blue">

        </section>
        
        <section width="40%" height="500px" bgcolor="green">

        </section>
      </Container>
    </div>
  )
} */

/* function App(){
  return(
    
    <Container>
      <GlobalStyle />
      <Todo />
    </Container>
    
  )
}

export default App; */

import React from 'react'
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom'
import GlobalStyle from './components/common/global-style'
import GrobalNavbar from './components/common/global-navbar'
import HomePage from './pages/home'
import SigninPage from './pages/signin'
import TodoPage from './pages/todo'
import ErrorPage from './pages/error'

function App() {
  return (
    <Router>
      <GlobalStyle />
      <GrobalNavbar />
      <Switch>
        <Route exact path="/" component={HomePage} />
        <Route path="/todo" component={TodoPage} />
        <Route path="/signin" component={SigninPage} />
        <Route component={ErrorPage} />
      </Switch>
    </Router>
  )
}

export default App
