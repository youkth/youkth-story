export default {
    blue: '#358fff',
    mint: '#26cec2',
    red: '#fd2e68',
    black: '#3a3a3a',
    gray: '#dedede',
    white: '#ffffff'
}