import styled from 'styled-components'
import COLORS from '../color'

/**
 * borderRadius, margin, padding, fontSize, color, disable, full
 */

export default styled.button`
  border: none;
  color: ${COLORS.white};
  cursor:pointer;
  display:inline-block;
  ${({ full }) => full && `width: 100%;`}
  ${({ width }) => width && `width: ${width};`}
  ${({ margin }) => margin && `margin: ${margin};`}
  ${({ center }) => center && `display:block; width:500px; margin: 0 auto;`}
  ${({ padding }) => padding && `padding: ${padding};`}
  ${({ fontSize }) => `font-size: ${fontSize || 15}px;`}
  ${({ color }) => `background: ${COLORS[color] || COLORS.blue};`}
  ${({ disable }) => disable && `background: ${COLORS.gray};`}
  ${({ fcolor }) => fcolor && `color: ${fcolor};`}
  ${({ size }) => size && `font-size: ${size};`}
`