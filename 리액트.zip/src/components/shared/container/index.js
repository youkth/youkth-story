import styled from "styled-components";

export default styled.div`
    box-sizing:border-box;
    ${({basic}) => basic && `width:100%; max-width:700px; margin:50px auto 0 auto;`}
    ${({display}) => display && `display:${display};`}
    ${({block}) => block && `display:block;`}
    ${({inlineblock}) => inlineblock && `display:inline-block;`}
    ${({center}) => center && `font-size:0; text-align:center;`}
    ${({hbg}) => hbg && `&.active,&:hover{background:${hbg}};`}
    ${({hcolor}) => hcolor && `&.active,&:hover{color:${hcolor}};`}
    ${({flex}) => flex && `display:flex;`}
    ${({flexCenter}) => flexCenter && `display:flex; align-items: center;`}
    ${({width}) => width && `width:${width};`}
    ${({maxwidth}) => maxwidth && `max-width:${maxwidth};`}
    ${({minwidth}) => minwidth && `min-width:${minwidth};`}
    ${({height}) => height && `height:${height};`}
    ${({margin}) => margin && `margin:${margin};`}
    ${({padding}) => padding && `padding:${padding};`}
    ${({border}) => border && `border:${border};`}
    background-color:${({bgcolor}) => bgcolor || `#fff`};
    ${({border}) => border && `border:${border};`}
    ${({bdTop}) => bdTop && `border-top:${bdTop};`}
    ${({bdBottom}) => bdBottom && `border-bottom:${bdBottom};`}
    ${({bdLeft}) => bdLeft && `border-left:${bdLeft};`} 
    ${({bdRight}) => bdRight && `border-right:${bdRight};`}
    ${({bg}) => bg && `background:${bg};`}
    ${({color}) => color && `color:${color};`}
`