import React from 'react'
import Form from './form'
import Userlist from './user-list'
import Container from '../shared/container'

function Signin(){
    return (
        <Container basic>
            <Form />
            <Userlist />
        </Container>
    )
}

export default Signin



