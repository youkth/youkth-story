import React from 'react'
import Signin from '.'


export default {
  title: 'Login',
  components: Signin,
}

export const BasicSignin = () => {
  return (
    <Signin />
  )
}

BasicSignin.story = {
  name: '에러체크',
}