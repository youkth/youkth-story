import React, { useState } from 'react'

import Input from '../shared/input'
import Container from '../shared/container'
import Button from '../shared/button'
import Text from '../shared/text'

function Form() {
  const [formValues, setFormValues] = useState({
    name: '',
    password: '',
  })

  const [isError, setIsError] = useState(false)

  const handleInput = (e) => {
    setFormValues({ ...formValues, [e.target.name]: e.target.value })
  }

  const handleSubmit = () => {const { name, password } = formValues

    setIsError(!name || !password)
  }

  return (
    <Container>
      <Container margin="15px 0;">
        <Text block margin="0 0 20px 0">이름을 입력하세요</Text>
        <Input name="name" onChange={handleInput} value={formValues.name}/>
      </Container>

      <Container margin="15px 0;">
        <Text block margin="0 0 20px 0">비밀번호를 입력하세요</Text>
        <Input name="password" onChange={handleInput} value={formValues.password}/>
      </Container>
      
      {isError ? (<Text color="red" margin="10px 0">정보를 전부 입력해 주세요</Text>) : null}
      
      <Button center padding="15px 0" color="mint" onClick={handleSubmit}>로그인</Button>
    </Container>
  )

}

export default Form
