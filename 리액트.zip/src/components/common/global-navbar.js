import React from 'react'
import {NavLink} from 'react-router-dom'
//import classnames from 'classnames';
import Container from '../shared/container'
import Text from '../shared/text'
//import styled from 'styled-components';

const Ul = Container.withComponent('ul');
const Li = Container.withComponent('li');
const Href = Container.withComponent(NavLink);


const PATH =[
    {
        path:'/',
        label:'home'
    },
    {
        path:'/todo',
        label:'todo'
    },
    {
        path:'/signin',
        label:'signin'
    },
    {
        path:'/error',
        label:'error'
    },
]

function GlobalNavbar(){
  
   return(
        <Container>
            <Ul center width="90%" margin="50px auto 0 auto">
                {PATH.map(({path, label},index)=>(
                    <Li key={index} margin="0 10px" inlineblock>
                        <Href to={path} exact={path === '/'} padding="10px 30px" border="1px solid #eee" bg="#333" hbg="blue" display="inline-block">
                            <Text size="20" color="white">{label}</Text>
                        </Href>
                    </Li>
                ))}
            </Ul>
        </Container>
    )
}

export default GlobalNavbar