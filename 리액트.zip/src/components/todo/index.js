import React, {useState, useEffect} from 'react'
import Container from '../shared/container'
//import Text from '../shared/text'

import Header from './header'
import Body from './body'
import Footer from './footer'
import {fetchTodos} from './service'


function Todo(){
const [todos, setTodos]=useState([])

useEffect(()=>{
  async function fetchAndSetTodos(){
    setTodos(await fetchTodos())
  } 
  fetchAndSetTodos()
},[])

const handleAdd = data => {
  console.log(data);
  setTodos([
    ...todos,
    {
      id:Date.now(),
      title:data,
      isDone:false
    }
  ])
}

const handleDelete = (id) => {setTodos(todos.filter(todo => todo.id !== id))}

const handleUpdateStatus = (id) => {
  setTodos(todos.map(todo => todo.id === id ? {...todo, isDone:!todo.isDone} : todo))
}

  return (
    <Container basic padding="30px" border="1px solid #dedede">
      <Header addData={handleAdd}/>
      <Body todos={todos} onDelete={handleDelete} onUpdateStatus={handleUpdateStatus}/>
      <Footer count={todos.length}/>
    </Container>
  )
}

export default Todo

//npx json-server --watch ./db.json --port 8000