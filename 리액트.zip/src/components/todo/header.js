import React, {useState} from 'react'
import Container from '../shared/container'
import Input from '../shared/input'
import Button from '../shared/button'
import Text from '../shared/text'

const H1 = Text.withComponent('h1');

function Header({addData}){
  const [text, setText] = useState("")

  const handleChange = (e) => setText(e.target.value)
  
  const handleClick = () => {
    if(text.length>0)
    addData(text)
    //console.log(text)
    setText("")
  }
  
  return (
    <Container>
      <H1 size="30" margin="0 0 20px 0" color="mint" bold center >TODO APP</H1>
      <Container flex>
        <Input type="text" width="80%" onChange={handleChange} value={text} placeholder="내용을 입력하세요." />
        <Button width="20%" onClick={handleClick}>내용추가</Button>
      </Container>
    </Container>
  )
}

export default Header