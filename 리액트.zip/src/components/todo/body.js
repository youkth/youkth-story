import React from 'react'
import Container from '../shared/container'
import Input from '../shared/input'
import Text from '../shared/text'
import Button from '../shared/button'

function AddBox({todo:{id,title,isDone},onUpdateStatus, onDelete}){
  return(
    <Container flexCetner padding="10px 0" bdBottom="1px solid #dedede">
        <Input width="30px" height="30px" type="checkbox" defaultChecked={isDone} />
        <Text>{title}&nbsp;&nbsp;&nbsp;{isDone ? "[완료]" : "[진행중]"}</Text>
        <Button onClick={() => onDelete(id)} disable size="12px" fcolor="#333" margin="0 0 0 10px" padding="3px 10px" >DELETE</Button>
    </Container>
  )
}

function Body({todos, onDelete, onUpdateStatus}){
  return (
    <Container>
      {todos.map((todo) => <AddBox todo={todo} onDelete={onDelete} onUpdateStatus={onUpdateStatus} key={todo.id} />)}
    </Container>
  )
}

export default Body