import React from 'react'
import Container from '../shared/container'

function Footer({count}){
  return (
  <Container margin="20px 0 0 0" padding="5px 10px" bg="#26cec2" color="#fff">{count} : ITEM</Container>
  )
}

export default Footer